import { InsertUser, User, Post, Like, Comment, Message, ChatGroup, ChatGroupMember, GroupMessage, Follower } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Post methods
  createPost(userId: number, imageUrl: string, caption?: string): Promise<Post>;
  getPosts(limit: number, offset: number): Promise<Post[]>;
  getPostById(id: number): Promise<Post | undefined>;

  // Like methods
  createLike(userId: number, postId: number): Promise<Like>;
  deleteLike(userId: number, postId: number): Promise<void>;
  getLikes(postId: number): Promise<Like[]>;

  // Comment methods
  createComment(userId: number, postId: number, content: string): Promise<Comment>;
  getComments(postId: number): Promise<Comment[]>;

  // Direct message methods
  createMessage(senderId: number, receiverId: number, content: string): Promise<Message>;
  getMessages(userId1: number, userId2: number, limit: number): Promise<Message[]>;

  // Group chat methods
  createGroup(name: string): Promise<ChatGroup>;
  addGroupMember(groupId: number, userId: number): Promise<ChatGroupMember>;
  removeGroupMember(groupId: number, userId: number): Promise<void>;
  getGroupMembers(groupId: number): Promise<ChatGroupMember[]>;
  createGroupMessage(groupId: number, senderId: number, content: string): Promise<GroupMessage>;
  getGroupMessages(groupId: number, limit: number): Promise<GroupMessage[]>;
  getUserGroups(userId: number): Promise<ChatGroup[]>;

  // Following methods
  followUser(followerId: number, followingId: number): Promise<Follower>;
  unfollowUser(followerId: number, followingId: number): Promise<void>;
  getFollowers(userId: number): Promise<User[]>;
  getFollowing(userId: number): Promise<User[]>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private likes: Map<number, Like>;
  private comments: Map<number, Comment>;
  private messages: Map<number, Message>;
  private chatGroups: Map<number, ChatGroup>;
  private chatGroupMembers: Map<number, ChatGroupMember>;
  private groupMessages: Map<number, GroupMessage>;
  private followers: Map<number, Follower>;
  sessionStore: session.Store;
  private currentId: Record<string, number>;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.likes = new Map();
    this.comments = new Map();
    this.messages = new Map();
    this.chatGroups = new Map();
    this.chatGroupMembers = new Map();
    this.groupMessages = new Map();
    this.followers = new Map();
    this.currentId = { 
      users: 1, 
      posts: 1, 
      likes: 1, 
      comments: 1, 
      messages: 1,
      chatGroups: 1,
      chatGroupMembers: 1,
      groupMessages: 1,
      followers: 1
    };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { ...insertUser, id, avatarUrl: null };
    this.users.set(id, user);
    return user;
  }

  async createPost(userId: number, imageUrl: string, caption?: string): Promise<Post> {
    const id = this.currentId.posts++;
    const post: Post = {
      id,
      userId,
      imageUrl,
      caption: caption || null,
      createdAt: new Date(),
    };
    this.posts.set(id, post);
    return post;
  }

  async getPosts(limit: number, offset: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(offset, offset + limit);
  }

  async getPostById(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async createLike(userId: number, postId: number): Promise<Like> {
    const id = this.currentId.likes++;
    const like: Like = { id, userId, postId };
    this.likes.set(id, like);
    return like;
  }

  async deleteLike(userId: number, postId: number): Promise<void> {
    const like = Array.from(this.likes.values()).find(
      (l) => l.userId === userId && l.postId === postId,
    );
    if (like) {
      this.likes.delete(like.id);
    }
  }

  async getLikes(postId: number): Promise<Like[]> {
    return Array.from(this.likes.values()).filter((l) => l.postId === postId);
  }

  async createComment(userId: number, postId: number, content: string): Promise<Comment> {
    const id = this.currentId.comments++;
    const comment: Comment = {
      id,
      userId,
      postId,
      content,
      createdAt: new Date(),
    };
    this.comments.set(id, comment);
    return comment;
  }

  async getComments(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter((c) => c.postId === postId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async createMessage(senderId: number, receiverId: number, content: string): Promise<Message> {
    const id = this.currentId.messages++;
    const message: Message = {
      id,
      senderId,
      receiverId,
      content,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessages(userId1: number, userId2: number, limit: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(
        (m) =>
          (m.senderId === userId1 && m.receiverId === userId2) ||
          (m.senderId === userId2 && m.receiverId === userId1)
      )
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit);
  }

  async createGroup(name: string): Promise<ChatGroup> {
    const id = this.currentId.chatGroups++;
    const group: ChatGroup = {
      id,
      name,
      createdAt: new Date(),
    };
    this.chatGroups.set(id, group);
    return group;
  }

  async addGroupMember(groupId: number, userId: number): Promise<ChatGroupMember> {
    const id = this.currentId.chatGroupMembers++;
    const member: ChatGroupMember = {
      id,
      groupId,
      userId,
      createdAt: new Date(),
    };
    this.chatGroupMembers.set(id, member);
    return member;
  }

  async removeGroupMember(groupId: number, userId: number): Promise<void> {
    const member = Array.from(this.chatGroupMembers.values()).find(
      (m) => m.groupId === groupId && m.userId === userId
    );
    if (member) {
      this.chatGroupMembers.delete(member.id);
    }
  }

  async getGroupMembers(groupId: number): Promise<ChatGroupMember[]> {
    return Array.from(this.chatGroupMembers.values())
      .filter((m) => m.groupId === groupId);
  }

  async createGroupMessage(groupId: number, senderId: number, content: string): Promise<GroupMessage> {
    const id = this.currentId.groupMessages++;
    const message: GroupMessage = {
      id,
      groupId,
      senderId,
      content,
      createdAt: new Date(),
    };
    this.groupMessages.set(id, message);
    return message;
  }

  async getGroupMessages(groupId: number, limit: number): Promise<GroupMessage[]> {
    return Array.from(this.groupMessages.values())
      .filter((m) => m.groupId === groupId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit);
  }

  async getUserGroups(userId: number): Promise<ChatGroup[]> {
    const memberGroups = Array.from(this.chatGroupMembers.values())
      .filter((m) => m.userId === userId)
      .map((m) => m.groupId);
    return Array.from(this.chatGroups.values())
      .filter((g) => memberGroups.includes(g.id));
  }

  async followUser(followerId: number, followingId: number): Promise<Follower> {
    const id = this.currentId.followers++;
    const follower: Follower = {
      id,
      followerId,
      followingId,
      createdAt: new Date(),
    };
    this.followers.set(id, follower);
    return follower;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<void> {
    const follow = Array.from(this.followers.values()).find(
      (f) => f.followerId === followerId && f.followingId === followingId
    );
    if (follow) {
      this.followers.delete(follow.id);
    }
  }

  async getFollowers(userId: number): Promise<User[]> {
    const followerIds = Array.from(this.followers.values())
      .filter((f) => f.followingId === userId)
      .map((f) => f.followerId);
    return Array.from(this.users.values())
      .filter((u) => followerIds.includes(u.id));
  }

  async getFollowing(userId: number): Promise<User[]> {
    const followingIds = Array.from(this.followers.values())
      .filter((f) => f.followerId === userId)
      .map((f) => f.followingId);
    return Array.from(this.users.values())
      .filter((u) => followingIds.includes(u.id));
  }
}

export const storage = new MemStorage();