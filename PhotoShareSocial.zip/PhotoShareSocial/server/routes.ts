import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import multer from "multer";
import sharp from "sharp";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertCommentSchema, insertGroupSchema } from "@shared/schema";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    next();
  };

  app.post("/api/posts", requireAuth, upload.single("image"), async (req, res) => {
    if (!req.file) {
      return res.status(400).send("No image provided");
    }

    const optimizedImageBuffer = await sharp(req.file.buffer)
      .resize(1080, 1080, { fit: "inside" })
      .jpeg({ quality: 80 })
      .toBuffer();

    // In a real app, we'd upload to S3/etc and get a URL
    // For now, we'll use a data URL
    const imageUrl = `data:image/jpeg;base64,${optimizedImageBuffer.toString("base64")}`;
    
    const post = await storage.createPost(
      req.user!.id,
      imageUrl,
      req.body.caption
    );
    
    res.status(201).json(post);
  });

  app.get("/api/posts", requireAuth, async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = parseInt(req.query.offset as string) || 0;
    
    const posts = await storage.getPosts(limit, offset);
    res.json(posts);
  });

  app.post("/api/posts/:postId/likes", requireAuth, async (req, res) => {
    const postId = parseInt(req.params.postId);
    const like = await storage.createLike(req.user!.id, postId);
    res.status(201).json(like);
  });

  app.delete("/api/posts/:postId/likes", requireAuth, async (req, res) => {
    const postId = parseInt(req.params.postId);
    await storage.deleteLike(req.user!.id, postId);
    res.sendStatus(200);
  });

  app.get("/api/posts/:postId/likes", requireAuth, async (req, res) => {
    const postId = parseInt(req.params.postId);
    const likes = await storage.getLikes(postId);
    res.json(likes);
  });

  app.post("/api/posts/:postId/comments", requireAuth, async (req, res) => {
    const postId = parseInt(req.params.postId);
    const validatedData = insertCommentSchema.parse(req.body);
    
    const comment = await storage.createComment(
      req.user!.id,
      postId,
      validatedData.content
    );
    
    res.status(201).json(comment);
  });

  app.get("/api/posts/:postId/comments", requireAuth, async (req, res) => {
    const postId = parseInt(req.params.postId);
    const comments = await storage.getComments(postId);
    res.json(comments);
  });

  // Following routes
  app.post("/api/follow/:userId", requireAuth, async (req, res) => {
    const followingId = parseInt(req.params.userId);
    if (followingId === req.user!.id) {
      return res.status(400).send("Cannot follow yourself");
    }
    const follow = await storage.followUser(req.user!.id, followingId);
    res.status(201).json(follow);
  });

  app.delete("/api/follow/:userId", requireAuth, async (req, res) => {
    const followingId = parseInt(req.params.userId);
    await storage.unfollowUser(req.user!.id, followingId);
    res.sendStatus(200);
  });

  app.get("/api/users/:userId/followers", requireAuth, async (req, res) => {
    const userId = parseInt(req.params.userId);
    const followers = await storage.getFollowers(userId);
    res.json(followers);
  });

  app.get("/api/users/:userId/following", requireAuth, async (req, res) => {
    const userId = parseInt(req.params.userId);
    const following = await storage.getFollowing(userId);
    res.json(following);
  });

  // Chat group routes
  app.post("/api/groups", requireAuth, async (req, res) => {
    const validatedData = insertGroupSchema.parse(req.body);
    const group = await storage.createGroup(validatedData.name);
    await storage.addGroupMember(group.id, req.user!.id);
    res.status(201).json(group);
  });

  app.post("/api/groups/:groupId/members", requireAuth, async (req, res) => {
    const groupId = parseInt(req.params.groupId);
    const userId = parseInt(req.body.userId);
    const member = await storage.addGroupMember(groupId, userId);
    res.status(201).json(member);
  });

  app.delete("/api/groups/:groupId/members/:userId", requireAuth, async (req, res) => {
    const groupId = parseInt(req.params.groupId);
    const userId = parseInt(req.params.userId);
    await storage.removeGroupMember(groupId, userId);
    res.sendStatus(200);
  });

  app.get("/api/groups/:groupId/members", requireAuth, async (req, res) => {
    const groupId = parseInt(req.params.groupId);
    const members = await storage.getGroupMembers(groupId);
    res.json(members);
  });

  app.get("/api/users/:userId/groups", requireAuth, async (req, res) => {
    const userId = parseInt(req.params.userId);
    const groups = await storage.getUserGroups(userId);
    res.json(groups);
  });

  const httpServer = createServer(app);

  // Set up WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws, req) => {
    // Parse cookies to get session ID
    const cookies = req.headers.cookie?.split(';').reduce((acc, cookie) => {
      const [key, value] = cookie.trim().split('=');
      acc[key] = value;
      return acc;
    }, {} as Record<string, string>);

    // Get session ID from cookie
    const sessionId = cookies?.['connect.sid'];
    if (!sessionId) {
      ws.close();
      return;
    }

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());

        if (message.type === 'direct') {
          const savedMessage = await storage.createMessage(
            message.senderId,
            message.receiverId,
            message.content
          );

          // Broadcast to all clients - they will filter based on senderId/receiverId
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'direct',
                message: savedMessage
              }));
            }
          });
        }

        if (message.type === 'group') {
          const savedMessage = await storage.createGroupMessage(
            message.groupId,
            message.senderId,
            message.content
          );

          // Broadcast to all clients - they will filter based on groupId
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'group',
                message: savedMessage
              }));
            }
          });
        }
      } catch (error) {
        console.error('Failed to process message:', error);
      }
    });
  });

  return httpServer;
}