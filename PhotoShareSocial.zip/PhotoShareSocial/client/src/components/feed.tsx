import { useInfiniteQuery } from "@tanstack/react-query";
import PostCard from "./post-card";
import { Post } from "@shared/schema";
import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

const POSTS_PER_PAGE = 5;

export default function Feed() {
  const { ref, inView } = useInView();

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    status,
  } = useInfiniteQuery({
    queryKey: ["/api/posts"],
    queryFn: async ({ pageParam = 0 }) => {
      const response = await fetch(
        `/api/posts?offset=${pageParam}&limit=${POSTS_PER_PAGE}`,
        { credentials: "include" }
      );
      const posts = await response.json();
      return posts;
    },
    getNextPageParam: (lastPage, pages) => {
      return lastPage.length === POSTS_PER_PAGE
        ? pages.length * POSTS_PER_PAGE
        : undefined;
    },
  });

  useEffect(() => {
    if (inView && hasNextPage) {
      fetchNextPage();
    }
  }, [inView, fetchNextPage, hasNextPage]);

  if (status === "pending") {
    return (
      <Card>
        <CardContent className="h-96 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (status === "error") {
    return <div>Error loading posts</div>;
  }

  return (
    <div className="space-y-8">
      {data.pages.map((group, i) => (
        <div key={i} className="space-y-8">
          {group.map((post: Post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      ))}
      
      <div ref={ref} className="h-8 flex items-center justify-center">
        {isFetchingNextPage && (
          <Loader2 className="h-6 w-6 animate-spin" />
        )}
      </div>
    </div>
  );
}
