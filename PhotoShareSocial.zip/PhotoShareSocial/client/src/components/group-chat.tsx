import { useEffect, useRef, useState } from "react";
import { useChat } from "@/hooks/use-chat";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { ChatGroup, ChatGroupMember, User } from "@shared/schema";

export default function GroupChat({ group }: { group: ChatGroup }) {
  const { user } = useAuth();
  const { sendGroupMessage, groupMessages, connectionStatus } = useChat();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const messages = groupMessages[group.id] || [];

  const { data: members = [] } = useQuery<ChatGroupMember[]>({
    queryKey: [`/api/groups/${group.id}/members`],
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const getUsername = (userId: number) => {
    const user = users.find((u) => u.id === userId);
    return user?.username || "Unknown User";
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendGroupMessage(group.id, message);
    setMessage("");
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>{group.name}</span>
          <div className="flex -space-x-2">
            {members.slice(0, 3).map((member) => (
              <Avatar key={member.id} className="border-2 border-background">
                <AvatarFallback>
                  {getUsername(member.userId)[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
            ))}
            {members.length > 3 && (
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm">
                +{members.length - 3}
              </div>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${
                  msg.senderId === user?.id ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    msg.senderId === user?.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  {msg.senderId !== user?.id && (
                    <p className="text-xs font-medium mb-1">
                      {getUsername(msg.senderId)}
                    </p>
                  )}
                  <p className="text-sm">{msg.content}</p>
                  <span className="text-xs opacity-70">
                    {format(new Date(msg.createdAt), "p")}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
        <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
          <Input
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={connectionStatus !== "connected"}
          />
          <Button type="submit" disabled={connectionStatus !== "connected"}>
            Send
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
