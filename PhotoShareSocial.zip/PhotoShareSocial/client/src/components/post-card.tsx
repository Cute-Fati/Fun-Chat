import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle } from "lucide-react";
import { Post, Comment } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";

export default function PostCard({ post }: { post: Post }) {
  const { user } = useAuth();
  const [comment, setComment] = useState("");

  const { data: likes = [] } = useQuery({
    queryKey: [`/api/posts/${post.id}/likes`],
  });

  const { data: comments = [] } = useQuery({
    queryKey: [`/api/posts/${post.id}/comments`],
  });

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (likes.some((l) => l.userId === user!.id)) {
        await apiRequest("DELETE", `/api/posts/${post.id}/likes`);
      } else {
        await apiRequest("POST", `/api/posts/${post.id}/likes`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}/likes`] });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/posts/${post.id}/comments`, {
        content: comment,
      });
      setComment("");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}/comments`] });
    },
  });

  const isLiked = likes.some((l) => l.userId === user!.id);

  return (
    <Card>
      <CardContent className="p-0">
        <img
          src={post.imageUrl}
          alt="Post"
          className="w-full aspect-square object-cover"
        />
      </CardContent>
      <CardContent className="pt-6">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => likeMutation.mutate()}
            disabled={likeMutation.isPending}
          >
            <Heart
              className={isLiked ? "fill-red-500 text-red-500" : "text-foreground"}
            />
          </Button>
          <span>{likes.length} likes</span>
        </div>

        {post.caption && (
          <p className="text-sm text-muted-foreground mb-4">{post.caption}</p>
        )}

        <div className="space-y-2">
          {comments.map((comment: Comment) => (
            <div key={comment.id} className="flex items-start gap-2">
              <Avatar className="h-6 w-6">
                <AvatarFallback>
                  {comment.userId.toString()[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm">{comment.content}</p>
                <span className="text-xs text-muted-foreground">
                  {format(new Date(comment.createdAt), "PP")}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            commentMutation.mutate();
          }}
          className="flex-1 flex gap-2"
        >
          <Input
            placeholder="Add a comment..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <Button
            type="submit"
            disabled={!comment.trim() || commentMutation.isPending}
          >
            Post
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
