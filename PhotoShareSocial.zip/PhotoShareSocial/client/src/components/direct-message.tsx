import { useEffect, useRef, useState } from "react";
import { useChat } from "@/hooks/use-chat";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { User } from "@shared/schema";

export default function DirectMessage({ otherUser }: { otherUser: User }) {
  const { user } = useAuth();
  const { sendDirectMessage, directMessages, connectionStatus } = useChat();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const messages = directMessages[otherUser.id] || [];

  const { data: initialMessages } = useQuery({
    queryKey: [`/api/messages/${otherUser.id}`],
  });

  useEffect(() => {
    if (initialMessages && !directMessages[otherUser.id]) {
      // Add initial messages to the chat context
    }
  }, [initialMessages, otherUser.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendDirectMessage(otherUser.id, message);
    setMessage("");
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Avatar>
            <AvatarFallback>
              {otherUser.username[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span>{otherUser.username}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${
                  msg.senderId === user?.id ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    msg.senderId === user?.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{msg.content}</p>
                  <span className="text-xs opacity-70">
                    {format(new Date(msg.createdAt), "p")}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
        <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
          <Input
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={connectionStatus !== "connected"}
          />
          <Button type="submit" disabled={connectionStatus !== "connected"}>
            Send
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
