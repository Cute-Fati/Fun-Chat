import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import CreatePost from "@/components/create-post";
import Feed from "@/components/feed";
import DirectMessage from "@/components/direct-message";
import GroupChat from "@/components/group-chat";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, ChatGroup } from "@shared/schema";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { MessageCircle, Users, X, Search, Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<ChatGroup | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [groupName, setGroupName] = useState("");
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: groups = [] } = useQuery<ChatGroup[]>({
    queryKey: [`/api/users/${user?.id}/groups`],
  });

  const otherUsers = users.filter((u) => u.id !== user?.id);
  const filteredUsers = searchQuery
    ? otherUsers.filter((u) =>
        u.username.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : otherUsers;

  const handleCreateGroup = async () => {
    if (!groupName.trim() || selectedUsers.length === 0) {
      toast({
        title: "Error",
        description: "Please enter a group name and select at least one user",
        variant: "destructive",
      });
      return;
    }

    try {
      const group = await apiRequest("POST", "/api/groups", { name: groupName });
      const groupData = await group.json();

      // Add selected users to the group
      await Promise.all(
        selectedUsers.map((userId) =>
          apiRequest("POST", `/api/groups/${groupData.id}/members`, { userId })
        )
      );

      queryClient.invalidateQueries({ queryKey: [`/api/users/${user?.id}/groups`] });
      setGroupName("");
      setSelectedUsers([]);
      toast({
        title: "Success",
        description: "Group created successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create group",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Fun Chat</h1>
          <div className="flex items-center gap-4">
            <Sheet open={isChatOpen} onOpenChange={setIsChatOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <MessageCircle className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent className="w-[400px] sm:max-w-none">
                <SheetHeader>
                  <SheetTitle>Chats</SheetTitle>
                </SheetHeader>
                <Tabs defaultValue="direct" className="mt-4">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="direct">Direct Messages</TabsTrigger>
                    <TabsTrigger value="groups">Group Chats</TabsTrigger>
                  </TabsList>
                  <TabsContent value="direct" className="mt-4">
                    <div className="mb-4">
                      <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Search users..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-8"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      {filteredUsers.map((otherUser) => (
                        <Button
                          key={otherUser.id}
                          variant={selectedUser?.id === otherUser.id ? "secondary" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setSelectedUser(otherUser)}
                        >
                          <span>{otherUser.username}</span>
                        </Button>
                      ))}
                    </div>
                    {selectedUser && (
                      <div className="mt-4">
                        <DirectMessage otherUser={selectedUser} />
                      </div>
                    )}
                  </TabsContent>
                  <TabsContent value="groups" className="mt-4">
                    <div className="mb-4">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button className="w-full">
                            <Plus className="h-4 w-4 mr-2" />
                            Create New Group
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Create New Group</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <Input
                              placeholder="Group name"
                              value={groupName}
                              onChange={(e) => setGroupName(e.target.value)}
                            />
                            <div className="space-y-2">
                              <h4 className="text-sm font-medium">Select Members</h4>
                              {otherUsers.map((u) => (
                                <div key={u.id} className="flex items-center gap-2">
                                  <input
                                    type="checkbox"
                                    id={`user-${u.id}`}
                                    checked={selectedUsers.includes(u.id)}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedUsers([...selectedUsers, u.id]);
                                      } else {
                                        setSelectedUsers(selectedUsers.filter(id => id !== u.id));
                                      }
                                    }}
                                  />
                                  <label htmlFor={`user-${u.id}`}>{u.username}</label>
                                </div>
                              ))}
                            </div>
                            <Button onClick={handleCreateGroup}>Create Group</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                    <div className="space-y-2">
                      {groups.map((group) => (
                        <Button
                          key={group.id}
                          variant={selectedGroup?.id === group.id ? "secondary" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setSelectedGroup(group)}
                        >
                          <Users className="h-4 w-4 mr-2" />
                          <span>{group.name}</span>
                        </Button>
                      ))}
                    </div>
                    {selectedGroup && (
                      <div className="mt-4">
                        <GroupChat group={selectedGroup} />
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </SheetContent>
            </Sheet>
            <span>Welcome, {user?.username}!</span>
            <Button
              variant="outline"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <CreatePost />
        <div className="mt-8">
          <Feed />
        </div>
      </main>
    </div>
  );
}