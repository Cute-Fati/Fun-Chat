import { createContext, ReactNode, useContext, useEffect, useRef, useState } from "react";
import { useAuth } from "./use-auth";
import { Message, GroupMessage } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

type ChatContextType = {
  sendDirectMessage: (receiverId: number, content: string) => void;
  sendGroupMessage: (groupId: number, content: string) => void;
  directMessages: Record<number, Message[]>;
  groupMessages: Record<number, GroupMessage[]>;
  connectionStatus: "connecting" | "connected" | "disconnected";
};

const ChatContext = createContext<ChatContextType | null>(null);

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [connectionStatus, setConnectionStatus] = useState<"connecting" | "connected" | "disconnected">("connecting");
  const [directMessages, setDirectMessages] = useState<Record<number, Message[]>>({});
  const [groupMessages, setGroupMessages] = useState<Record<number, GroupMessage[]>>({});
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!user) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setConnectionStatus("connected");
      toast({
        title: "Connected to chat",
        description: "You can now send and receive messages",
      });
    };

    ws.onclose = () => {
      setConnectionStatus("disconnected");
      toast({
        title: "Disconnected from chat",
        description: "Attempting to reconnect...",
        variant: "destructive",
      });
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "direct") {
        const message = data.message as Message;
        setDirectMessages((prev) => {
          const chatId = message.senderId === user.id ? message.receiverId : message.senderId;
          return {
            ...prev,
            [chatId]: [...(prev[chatId] || []), message],
          };
        });
      } else if (data.type === "group") {
        const message = data.message as GroupMessage;
        setGroupMessages((prev) => ({
          ...prev,
          [message.groupId]: [...(prev[message.groupId] || []), message],
        }));
      }
    };

    wsRef.current = ws;
    return () => ws.close();
  }, [user, toast]);

  const sendDirectMessage = (receiverId: number, content: string) => {
    if (!wsRef.current || !user) return;
    wsRef.current.send(
      JSON.stringify({
        type: "direct",
        senderId: user.id,
        receiverId,
        content,
      })
    );
  };

  const sendGroupMessage = (groupId: number, content: string) => {
    if (!wsRef.current || !user) return;
    wsRef.current.send(
      JSON.stringify({
        type: "group",
        groupId,
        senderId: user.id,
        content,
      })
    );
  };

  return (
    <ChatContext.Provider
      value={{
        sendDirectMessage,
        sendGroupMessage,
        directMessages,
        groupMessages,
        connectionStatus,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
}
